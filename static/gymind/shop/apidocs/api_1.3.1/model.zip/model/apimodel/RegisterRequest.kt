package model.apimodel

data class RegisterRequest(
		val name: String,
		val password: String,
		val role: Int
)