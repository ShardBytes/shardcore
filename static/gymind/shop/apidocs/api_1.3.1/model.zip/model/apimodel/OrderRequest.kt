package model.apimodel

import model.ShopOrderTarget

/**
 * Order request protocol.
 */

data class OrderRequest(
		val targets: List<ShopOrderTarget>,
		val location: String
)