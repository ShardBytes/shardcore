package model.apimodel

data class CompleteOrderRequest(
	val number: Long,
	val password: String
)