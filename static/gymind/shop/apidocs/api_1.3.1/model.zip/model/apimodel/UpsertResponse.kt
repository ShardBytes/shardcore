package model.apimodel

data class UpsertResponse(
		val name: String,
		val modifiedCount: Long,
		val upserted: Boolean
)