package model.apimodel

import model.User

data class UserInfo(
		val username: String,
		val role: Int,
		val balance: Long
) {
	constructor(user: User) : this(user.name, user.role, user.balance)
}