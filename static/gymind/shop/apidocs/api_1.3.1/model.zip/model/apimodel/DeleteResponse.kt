package model.apimodel

data class DeleteResponse(
		val name: String,
		val deletedCount: Long
)