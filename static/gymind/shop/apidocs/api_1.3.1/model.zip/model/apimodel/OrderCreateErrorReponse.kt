package model.apimodel

data class OrderCreateErrorReponse(
		val missingCredit: Long,
		val notInStock: String
)