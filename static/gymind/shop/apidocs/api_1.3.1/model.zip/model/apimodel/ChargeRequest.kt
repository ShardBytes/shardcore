package model.apimodel

data class ChargeRequest(
		val username: String,
		val amount: Long // amount of credits to charge
)