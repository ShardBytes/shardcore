package model

data class ShopOrder(
		var number: Long, // ID of order (using serverstate!)
		val password: String, // password for checking the order (probably a 4 digit number is ok )
		
		val date: Long,
		val username: String, // name of the user who did the order
		var status: Int,
		val location: String,
		
		// order target items, the amount may be changed respective to order ! -> this is because orders should save the items
		// state when created so user (and we) can review the instantaneous order at that time
		val targets: List<ShopItem>,
		
		var sum: Long // the complete checkout sum of item prices of that order, SET THIS WHEN CLOSING ORDER!
) {
	
	companion object {
		const val STATUS_OPEN = 0
		const val STATUS_IN_TRANSIT = 1 // probably unused for now
		const val STATUS_COMPLETED = 2
		const val STATUS_CANCELED = 3
	}
}