package model

data class ShopRecord(
		val name: String, // identifies shop record by name, mongo index
		val title: String, // title of record
		val description: String, // description of it
		val imageId: String, // id of image to show with record
		val contentType: Int, // ...
		val targets: MutableList<String> // points to names of items / records, depending on type of this record+
) {
	
	companion object {
		// content types -> types of things that are inside this record
		const val TYPE_ITEM = 0
		const val TYPE_CATEGORY = 1
	}
}