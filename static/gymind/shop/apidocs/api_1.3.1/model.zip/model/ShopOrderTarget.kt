package model

data class ShopOrderTarget(
		val name: String,
		val amount: Long
)