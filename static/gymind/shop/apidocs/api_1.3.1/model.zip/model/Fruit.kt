package model

data class Fruit(
		val name: String, // index
		val amount: Int
)
