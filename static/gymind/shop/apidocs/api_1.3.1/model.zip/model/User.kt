package model

import users.UserRoles
import users.UserSession

data class User (
		val name: String, // name of the user
		val hash: String, // hashed password of the user
		val role: Int = UserRoles.NORMAL, // normal role by default
		var balance: Long = 0, // how much credits are on the account
		val sessions: MutableList<UserSession> = mutableListOf()
)