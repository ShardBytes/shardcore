package model

data class ShopItem(
		var name: String, // index, identifies the item by its unique name
		var title: String,
		var description: String,
		var price: Long, // price is integer, use credits = integers
		
		// this amont has DIFFERENT MEANING if it is in:
		// - shop = amount on stock
		// - order = amount of how much of it was ordered
		var amount: Long,
		
		var imageId: String
)